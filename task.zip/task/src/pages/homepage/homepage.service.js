import en from "../../assets/language/en.json";

const database = {};

let hasStartedDataFetch = false;

const getList = async (selection) => {
    const response = {
        success: null,
        error: null,
    };

    let parameter =
        selection === en.dropdownOptions[0] ? "topalbums" : "topsongs";

    try {
        let success = await fetch(
            `https://itunes.apple.com/us/rss/${parameter}/limit=100/json`
        );
        success = await success.json();
        response.success = success;
    } catch (error) {
        response.error = error;
    } finally {
        return response;
    }
};

const getLyrics = async (item) => {
    const response = {
        success: null,
        error: null,
    };

    try {
        let success = await fetch(
            `https://api.lyrics.ovh/v1/${item["im:artist"]["label"]}/${item["im:name"]["label"]}`
        );
        success = await success.json();
        response.success = success;
    } catch (error) {
        response.error = error;
    } finally {
        return response;
    }
};

const getAllLyrics = (listOfItems) => {
    if (hasStartedDataFetch) return true;
    hasStartedDataFetch = true;

    try {
        for (let chunk = 0; chunk < listOfItems.length / 10; chunk++) {
            setTimeout(() => {
                for (let item of listOfItems.slice(chunk * 10, (chunk + 1) * 10)) {
                    (function (item) {
                        fetch(
                            `https://api.lyrics.ovh/v1/${item["im:artist"]["label"]}/${item["im:name"]["label"]}`
                        )
                            .then((response) => response.json())
                            .then((data) => {
                                database[item["id"]["attributes"]["im:id"].toString()] =
                                    data.lyrics.toLowerCase();
                            });
                    })(item);
                }
            }, chunk * 1000)
        }

    } catch (error) {
        console.log(error);
    }
};

const getDatabaseOfLyrics = () => database;

export const homepageService = {
    getList,
    getLyrics,
    getAllLyrics,
    getDatabaseOfLyrics,
};
