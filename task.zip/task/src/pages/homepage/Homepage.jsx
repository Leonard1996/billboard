import React, { useState, useEffect } from "react";
import {
  Container,
  Grid,
  Typography,
  Box,
  TextField,
  Checkbox,
  makeStyles,
} from "@material-ui/core";
import en from "../../assets/language/en.json";
import Dropdown from "../../components/dropdown/Dropdown";
import List from "../../components/list/List";
import { homepageService } from "./homepage.service";
import Drawer from "../../components/drawer/Drawer";
import homepageStyles from "./Homepage.styles";

const useStyles = makeStyles(homepageStyles);

const Homepage = () => {
  const classes = useStyles();

  const [selection, setSelection] = useState(en.dropdownOptions[0]);
  const [isLoading, setIsLoading] = useState(true);
  const [list, setList] = useState([]);
  const [unfilteredList, setUnfilteredList] = useState([]);
  const [isOpen, setIsOpen] = useState({
    modal: false,
    item: {},
  });

  const [checked, setChecked] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);
    const response = await homepageService.getList(selection);
    if (response.success) {
      setList(response.success.feed.entry);
      setUnfilteredList(response.success.feed.entry);
    }
    if (response.error) {
      window.alert(en.error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    fetchData();
  }, [selection]);

  const handleFilterChange = (event) => {
    const {
      target: { value },
    } = event;

    value ? filterEntries(value) : setList(unfilteredList);
  };

  const filterEntries = (queryString) => {
    const newEntries = unfilteredList.filter((entry) =>
      searchAlgorithm(queryString, entry)
    );

    setList(newEntries);
  };

  const searchAlgorithm = (queryString, entry) => {
    const database = homepageService.getDatabaseOfLyrics();
    queryString = queryString.toLowerCase();

    return (
      entry["im:artist"]["label"].toLowerCase().includes(queryString) ||
      entry["im:name"]["label"].toLowerCase().includes(queryString) ||
      (checked &&
        database[entry["id"]["attributes"]["im:id"]]?.includes(queryString))
    );
  };

  const handleCheckboxChange = () => {
    homepageService.getAllLyrics(unfilteredList);
    setChecked((prevChecked) => !prevChecked);
  };

  return (
    <>
      <Container width="md" data-testid="homepage">
        <Grid container justify="center">
          <Grid item xs={12}>
            <Box m={4}>
              <Typography variant="h3" color="textPrimary" align="center">
                {en.homepage.hero}
              </Typography>
            </Box>
          </Grid>
          <Grid item xs={12} sm={8} md={4}>
            <Dropdown selection={selection} setSelection={setSelection} />
          </Grid>
          <Grid item xs={12} sm={10} align="end">
            <Box
              paddingRight={4}
              marginTop={2}
              classes={{ root: classes.filters }}
            >
              <Checkbox
                color="primary"
                checked={checked}
                onChange={handleCheckboxChange}
              />
              <Box marginRight={2}>
                <Typography component="span">Include lyrics</Typography>
              </Box>
              <TextField
                placeholder={en.homepage.filter}
                variant="outlined"
                onChange={handleFilterChange}
              />
            </Box>
          </Grid>
          <Grid item xs={12}>
            <List
              isLoading={isLoading}
              list={list}
              unfilteredList={unfilteredList}
              selection={selection}
              setIsOpen={setIsOpen}
              isOpen={isOpen}
            />
          </Grid>
        </Grid>
      </Container>
      <Drawer isOpen={isOpen} setIsOpen={setIsOpen} />
    </>
  );
};

export default Homepage;
