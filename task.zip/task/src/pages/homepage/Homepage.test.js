import React from "react"
import { fireEvent, render } from '@testing-library/react';
import Homepage from "./Homepage";


it("renders correctly", () => {
    const { queryByTestId } = render(<Homepage />);
    expect(queryByTestId("homepage")).toBeTruthy();
})