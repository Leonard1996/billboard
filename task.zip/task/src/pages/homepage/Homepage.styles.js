const homepageStyles = {

    filters: {
        display: "flex",
        justifyContent: "flex-end",
        alignItems: "center",
    },
};

export default homepageStyles;