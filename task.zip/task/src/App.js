import React from 'react';
import {
  Switch,
  Route,
} from 'react-router-dom';
import Navbar from "./components/navbar/Navbar";
import Homepage from "./pages/homepage/Homepage";
import CustomRedirect from "./components/CustomRedirect/CustomRedirect";

function App() {
  return (
    <>
      <Navbar />
      <Switch>
        <Route exact path="/" component={Homepage} />
        <Route path="/" component={CustomRedirect} />
      </Switch>
    </>
  );
}

export default App;
