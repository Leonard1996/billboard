import React from "react";
import {
  Grid,
  CircularProgress,
  Divider,
  Typography,
  makeStyles,
} from "@material-ui/core";
import en from "../../assets/language/en.json";
import listStyles from "./List.styles";
import Entry from "../entry/Entry";

const useStyles = makeStyles(listStyles);

const List = ({
  isLoading,
  list,
  unfilteredList,
  selection,
  setIsOpen,
  isOpen,
}) => {
  const classes = useStyles();
  return (
    <Grid
      container
      justify="center"
      classes={{ root: classes.container }}
      data-testid="list"
    >
      {isLoading ? (
        <Grid item>
          <CircularProgress />
        </Grid>
      ) : (
        <Grid item xs={12} sm={10}>
          <Grid container justify="space-between">
            <Grid item xs={2} />
            <Grid item xs={4}>
              <Typography variant="body1" color="textSecondary" align="center">
                {en.list.artist}
              </Typography>
            </Grid>
            <Grid item xs={3}>
              <Typography variant="body1" color="textSecondary" align="center">
                {en.list.name}
              </Typography>
            </Grid>
            <Grid item xs={3}>
              <Typography variant="body1" color="textSecondary" align="center">
                {en.list.actions}
              </Typography>
            </Grid>
          </Grid>
          <Divider />
          <Grid item xs={12}>
            {list.map((item, _index) => (
              <Entry
                key={item["id"]["attributes"]["im:id"]}
                id={unfilteredList.indexOf(item)}
                item={item}
                selection={selection}
                setIsOpen={setIsOpen}
                isOpen={isOpen}
              />
            ))}
          </Grid>
        </Grid>
      )}
    </Grid>
  );
};

export default List;
