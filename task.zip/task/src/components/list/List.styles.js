const listStyles = {
    container: {
        padding: "32px",
    }
}

export default listStyles;