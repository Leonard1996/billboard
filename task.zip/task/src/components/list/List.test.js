import React from "react"
import { render, fireEvent } from '@testing-library/react';
import List from "./List";
import listStyles from "./List.styles";


it("renders correctly", () => {
    const { queryByTestId } = render(<List list={[]} />);
    expect(queryByTestId("list")).toBeTruthy();
})
