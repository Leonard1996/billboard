import React from "react"
import { render, fireEvent } from '@testing-library/react';
import Dropdown from "./Dropdown";
import en from "../../assets/language/en.json";
import List from "../list/List";

it('displays user data', async () => {
    const { queryByTestId } = render(<Dropdown />)

    fireEvent.change(queryByTestId("dropdown"), { target: { value: en.dropdownOptions[1] } })
    let response = fetch("https://itunes.apple.com/us/rss/topsongs/limit=100/json");
    response = await (await response).json()
    const { findByTestId } = render(<List list={response.feed.entry} />)
    expect(await findByTestId("list")).toHaveTextContent(response);

})


