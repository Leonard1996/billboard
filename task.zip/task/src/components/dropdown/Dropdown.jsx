import React from "react";
import { FormControl, Select, MenuItem, makeStyles } from "@material-ui/core";
import en from "../../assets/language/en.json";

const Dropdown = ({ selection, setSelection }) => {
  const handleSelectionChange = (event) => {
    setSelection(event.target.value);
  };

  return (
    <FormControl fullWidth>
      <Select
        value={selection}
        onChange={handleSelectionChange}
        inputProps={{ "data-testid": "dropdown" }}
      >
        {en.dropdownOptions.map((option, _index) => (
          <MenuItem key={_index} value={option}>
            {option}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
};

export default Dropdown;
