import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import en from "../../assets/language/en.json";

let timer = 3;

let timeout;

const CustomRedirect = () => {
  const [seconds, setSeconds] = useState(timer);

  const history = useHistory();

  const startTimer = () => {
    timeout = setTimeout(() => {
      setSeconds((prevSeconds) => prevSeconds - 1);
    }, 1000);
  };

  useEffect(() => {
    startTimer();
    if (!seconds) {
      history.push("/");
    }

    return () => clearTimeout(timeout);
  }, [seconds]);

  return (
    <h1>
      {en.redirect[0]}
      {seconds}
      {en.redirect[1]}
    </h1>
  );
};

export default CustomRedirect;
