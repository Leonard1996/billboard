const entryStyles = {
    container: {
        borderRadius: "0px",
        background: "#fefefe"
    },
    lyrics: {
        display: "flex",
        justifyContent: "center",
    },
    forbidden: {
        display: "flex",
        justifyContent: "center",
        cursor: "not-allowed",
    },
};

export default entryStyles;