import React from "react";
import {
  Card,
  CardContent,
  Grid,
  Typography,
  makeStyles,
  Button,
} from "@material-ui/core";
import en from "../../assets/language/en.json";
import entryStyles from "./Entry.styles";

const useStyles = makeStyles(entryStyles);

const Entry = ({ id, item, selection, setIsOpen }) => {
  const classes = useStyles();

  const handleLyricsClick = () => {
    setIsOpen({
      modal: true,
      item,
    });
  };

  return (
    <Card className={classes.container}>
      <CardContent>
        <Grid container alignItems="center">
          <Grid item xs={2}>
            <Typography variant="h6" color="primary" align="center">
              {id + 1}
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <img
              src={item["im:image"][0]["label"]}
              height={item["im:image"][0]["height"]}
            />
          </Grid>
          <Grid item xs={2}>
            <Typography variant="body1" noWrap>
              {item["im:artist"]["label"]}
            </Typography>
          </Grid>
          <Grid item xs={3} align="center">
            <Typography variant="body1" noWrap>
              {item["im:name"]["label"]}
            </Typography>
          </Grid>
          <Grid
            item
            xs={3}
            classes={{
              root:
                !selection === en.dropdownOptions[0]
                  ? classes.lyrics
                  : classes.forbidden,
            }}
          >
            <Button
              variant="outlined"
              color="primary"
              disabled={selection === en.dropdownOptions[0]}
              onClick={handleLyricsClick}
            >
              <Typography noWrap>{en.entry.lyrics}</Typography>
            </Button>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

export default Entry;
