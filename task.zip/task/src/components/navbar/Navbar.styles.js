const navBarStyles = {
    appBar: {
        backgroundColor: "black",
    },
    logo: {
        cursor: "pointer",
    }
}

export default navBarStyles;