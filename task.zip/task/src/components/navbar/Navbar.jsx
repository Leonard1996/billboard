import React from "react";
import { AppBar, Toolbar, makeStyles, Typography } from "@material-ui/core";
import navBarStyles from "./Navbar.styles";
import en from "../../assets/language/en.json";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles(navBarStyles);

const Navbar = () => {
  const classes = useStyles();

  const history = useHistory();

  const handleLogoClick = () => {
    history.push("/");
  };

  return (
    <AppBar position="static" data-testid="navbar">
      <Toolbar classes={{ root: classes.appBar }}>
        <Typography
          variant="h3"
          onClick={handleLogoClick}
          classes={{ root: classes.logo }}
          data-testid="icon"
        >
          {en.navbar.title}
        </Typography>
      </Toolbar>
    </AppBar>
  );
};

export default Navbar;
