const drawerStyles = {
    container: {
        padding: "16px",
        width: "300px",
    },
    wrapper: {
        minHeight: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center"
    }
}

export default drawerStyles;