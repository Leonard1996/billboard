import React, { useState, useEffect, useRef } from "react";
import {
  SwipeableDrawer,
  CircularProgress,
  makeStyles,
} from "@material-ui/core";
import { homepageService } from "../../pages/homepage/homepage.service";
import en from "../../assets/language/en.json";
import drawerStyles from "../drawer/Drawer.styles";

const useStyles = makeStyles(drawerStyles);
const Drawer = ({ isOpen, setIsOpen }) => {
  const classes = useStyles();
  const [isLoading, setIsLoading] = useState(false);
  const lyricsRef = useRef(null);

  const handleClose = () => {
    setIsOpen({
      ...isOpen,
      modal: false,
    });
  };

  const fetchLyrics = async () => {
    setIsLoading(true);
    const response = await homepageService.getLyrics(isOpen.item);
    if (response.success) {
      lyricsRef.current.innerHTML = response.success.lyrics.replace(
        new RegExp("\n", "g"),
        "<br>"
      );
    }
    if (response.error) {
      window.alert(en.error);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    isOpen.modal && fetchLyrics();
  }, [isOpen.modal]);

  return (
    <SwipeableDrawer
      anchor={"right"}
      open={isOpen.modal}
      onClose={handleClose}
      onOpen={() => {}}
    >
      <div className={isLoading ? classes.wrapper : ""}>
        {isLoading && <CircularProgress />}
        <div className={classes.container} ref={lyricsRef}></div>
      </div>
    </SwipeableDrawer>
  );
};

export default Drawer;
